<?php include 'include/head.php'; ?>

<div class="amid">
	<div class="left">
		<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy textxt Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Duxt
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t</p>
	</div>
	<div class="right">
		<img src="photos/images4.jpeg">
	</div>
	
</div>

<div class="amid2">
	<div class="left">
	<img src="photos/images1.jpeg" height="280" width="100%">
	
	   
</div>
<div class="center">
	<img src="photos/download1.jpeg" height="280" width="100%">
	
	 
</div>
<div class="right">
	<img src="photos/download2.jpeg" height="280" width="100%">
	
</div>
<div class="supright">
	<img src="photos/download.jpeg" height="280" width="100%">
	
	   
</div>
</div>

<?php include("include/footer.php") ; ?>