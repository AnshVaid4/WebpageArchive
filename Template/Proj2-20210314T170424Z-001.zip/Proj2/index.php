<div class="top">
	<div class="left" style="background-color: silver;">
		<table>
			<tr >
				<td style="font-size: 30px;padding-left: 40px;" >
					<b>Email:</b>
				</td>
				<td >
					<input type="email" name="em" placeholder="Enter email" style="height: 40px;width: 300px;font-size: 20px;">
				</td>
			</tr>
		</table>
	</div>
	<div class="right" style="background-color: silver;">
		<table>
			<tr>
				<td style="font-size: 30px;padding-left: 80px;">
					<b>Mobile:</b>
				</td>
				<td>
					<input type="number" name="num" placeholder="Enter mobile number"style="height: 40px;width: 300px;font-size: 20px;" >
				</td>
			</tr>
		</table>
	</div>
</div>

<?php include 'include/head.php'; ?>

<div class="logoAndWelcome" style="background-color: silver;">

<div class="logo">
	<img src="photos/logo.png" height="200">
</div>
<div class="welcome">
	<h1><u>WELCOME TO THE WEBENAR</u></h1>
</div>
</div>
<div class="mid">
	<h1 style="margin-left: 1020px;margin-bottom: 8px;x"><u>Heading1</u></h1>
<div class="left">
	<img src="photos/images1.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	   <table>
	   	<tr>
	   		<td colspan="2" align="center" width="50">
	   			<a href="services.php"><input type="button" name="readmore" value="Read More" style="padding-left: 10px;padding: 10px;padding-top: 5px;padding-bottom: 5px;margin-left: 50px;font-size: 20px;background-color: silver;margin-top: 10px"></a>
	   		</td>
	   	</tr>
	   </table>
</div>
<div class="center">
	<img src="photos/download1.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	   <table>
	   	<tr>
	   		<td colspan="2" align="center" width="50">
	   			<a href="services.php"><input type="button" name="readmore" value="Read More" style="padding: 5px 10px 5px 10px;margin-left: 50px;font-size: 20px;background-color: silver;margin-top: 10px"></a>
	   		</td>
	   	</tr>
	   </table>
</div>
<div class="right">
	<img src="photos/download2.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	  </p>
	   <table>
	   	<tr>
	   		<td colspan="2" align="center" width="50">
	   			<a href="services.php"><input type="button" name="readmore" value="Read More" style="padding: 5px 10px 5px 10px;margin-left: 50px;font-size: 20px;background-color: silver;margin-top: 10px"></a>
	   		</td>
	   	</tr>
	   </table>
</div>
<div class="supright">
	<img src="photos/download.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	   <table>
	   	<tr>
	   		<td colspan="2" align="center" width="50">
	   			<a href="services.php"><input type="button" name="readmore" value="Read More" style="padding: 5px 10px 5px 10px;margin-left: 50px;font-size: 20px;background-color: silver;margin-top: 10px"></a>
	   		</td>
	   	</tr>
	   </table>
</div>
</div>

<div class="beffooter">
	<div class="left">
		<img src="photos/images2.jpeg" height="380" width="96%">
	</div>
	<div class="right">
		<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t
	Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy t</p>
	</div>
</div>

<?php include("include/footer.php") ; ?>