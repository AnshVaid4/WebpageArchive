<?php include 'include/head.php';?>
<div class="fmid">
<div class="left">
	<?php include("include/feedback.php");?>
</div>
<div class="right">
	<img src="photos/images.jpeg" width="99%" >
</div>
</div>
<?php include("include/footer.php") ; ?>