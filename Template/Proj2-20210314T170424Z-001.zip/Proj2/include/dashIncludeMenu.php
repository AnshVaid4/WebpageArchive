<div class="left">
	<h2><u>DASHBOARD</u>
	</h2>
	<ul>
		<li style="font-size: 22px;"><a href="dashEmployeeAdd.php">Employee Add</a></li>
		<li style="font-size: 22px;"><a href="dashContactDisplay.php">Contact Dispay</a></li>
		<li style="font-size: 22px;"><a href="dashEmployeeDisplay.php">Employee Display</a></li>
		<li style="font-size: 22px;"><a href="dashFeedbackDisplay.php">Feedback Display</a></li>		
		<li style="font-size: 22px;"><a href="#">Logout</a></li>
	</ul>
</div>