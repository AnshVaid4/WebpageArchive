<!DOCTYPE html>
<html>
<head>
	<title>Webbenar</title>
	<link rel="stylesheet" type="text/css" href="css/style8.css">
</head>
<body>

<div class="header">
<div class="left">
	<h1><u>WEBENAR</u></h1>
</div>	
<div class="right">
	<ul>
		<li><a href="index.php" style="font-size: 30px;">Home</a></li>
		
		<li><a href="about.php"style="font-size: 30px;">About</a></li>
		<li><a href="services.php"style="font-size: 30px;">Services</a></li>
		<li><a href="feedback.php" style="font-size: 30px;">Feedback</a></li>
		<li><a href="contact.php"style="font-size: 30px;">Contact Us</a></li>
		<li><a href="login.php"style="font-size: 30px;margin-left: 20px;">Login</a>
		<li><a href="dashboard.php"style="font-size: 30px;margin-left: 8px;">Dashboard</a>
	</ul>
</div>
</div>