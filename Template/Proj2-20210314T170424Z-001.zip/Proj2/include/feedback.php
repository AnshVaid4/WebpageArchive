<div class="table">
<table  width="99%" cellspacing="20" cellpadding="0" align="center" bgcolor="whitesmoke" width="100%" style="height: 614px;margin-top: 8px">
	<tr>
	<th colspan="2" style="font-size: 40px;text-align: left;" height="20px">
		<u>FEEDBACK:</u>
	</th>
    </tr>
    <tr></tr>
    <tr></tr>
    <tr>
    	<td  width="150" style="font-size: 35px;">Username</td>
    	<td><input type="text" name="name" size="50" placeholder="Username" style="height: 40px;font-size: 20px"></td>
    </tr>
    <tr>
    	<td width="210" style="font-size: 35px;">Mobile</td>
    	<td><input type="number" name="mobile" size="50" placeholder="Mobile Number" style="height: 40px;width: 522px;font-size: 20px"></td>
    </tr> 
    <tr>
    	<td width="150" style="font-size: 35px;">Email</td>
    	<td><input type="email" name="email" size="50" placeholder="abc@gmail.com" style="height: 40px;font-size: 20px"></td>
    </tr>
    <tr>
    	<td width="150" style="font-size: 35px;">Website URL</td>
    	<td><input type="text" name="web" size="50" placeholder="Paste url of webpage that you didn't like" style="height: 40px;font-size: 20px"></td>
    </tr>
     <tr>
    	<td width="150" style="font-size: 35px;">Message</td>
    	<td><textarea rows="3" cols="47" placeholder="Write message here" style="font-size: 20px"></textarea></td>
    </tr>
    <tr>
    	<td colspan="2"><input type="button" name="save" value="SEND FEEDBACK" style="text-align: center;padding: 10px 20px 10px 20px;font-size: 20px;margin-left: 544px;background-color: silver;font-weight: bold;"></td></tr>

</table>
</div>