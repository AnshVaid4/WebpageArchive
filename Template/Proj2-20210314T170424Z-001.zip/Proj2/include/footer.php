<div class="footer">
<div class="flogo">
<img src="photos/logo.png" height="50">
</div>
<div class="ftext">
	<p>Copyright 2019-20. Designed And Developed By Infotech Department of Webenar</p>

</div>
</div>

</body>
</html>