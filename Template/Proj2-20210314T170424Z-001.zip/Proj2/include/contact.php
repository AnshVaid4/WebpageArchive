<!DOCTYPE html>
<html>
<head>
	<title>form</title>
</head>
<body>
<div class="contact">
	<br>
	<table align="center" bgcolor="whitesmoke" width="100%" style="height: 250px" cellspacing="15px" cellpadding="15px">
		<tr rowspan=2>
			<th style="font-size: 40px;"  align="left"><u>CONTACT:</u></th>
		</tr>
		<tr s>
			<td height="50" style="font-size: 30px;">Name</td>
			<td height="50" ><input type="text" name="name" placeholder="Enter your name" style="height: 30px;width: 320px;font-size: 20px;"></td>
		</tr>
		
			<td height="30" style="font-size: 30px;">Mobie</td>
			<td height="30"><input type="number" name="mobie" placeholder="Enter mobile number" style="height: 30px;width: 320px;font-size: 20px;"></td>
		</tr>
		<tr>
			<td height="30" style="font-size: 30px;">Service</td>
			<td height="30"><select name="course" style="height: 30px;width: 320px;font-size: 20px">
				<option value="null">Select Value</option>
				<option value="BLOGGING">BLOGGING</option>
				<option value="HOSTING">HOSTING</option>
				<option value="DEVELOPING">DEVELOPING</option>
				<option value="FREELANCING">FREELANCING</option>
				<option value="MANAGEMENT">MANAGEMENT</option>
			</select></td>
		</tr>
		<tr>
			<td height="30" style="font-size: 30px;">Email</td>
			<td height="30"><input type="email" name="email" placeholder="abc@gmail.com" style="height: 30px;width: 320px;font-size: 20px;"></td>
		</tr>
		<tr>
			<td height="30" style="font-size: 30px;">
				Message
			</td>
			<td height="30"><textarea rows="2" cols="28" placeholder="Enter text here" style="font-size: 20px"></textarea></td>
		</tr>
		<tr>
			<td colspan="2" align="center "><input type="submit" name="submit" value="SAVE" style="padding: 10px 20px 10px 20px;margin-left: 373px;font-weight: bolder;background-color: silver;font-size: 20px;" ></td>
		</tr>
		
	</table>
	
</div>
</body>
</html>
