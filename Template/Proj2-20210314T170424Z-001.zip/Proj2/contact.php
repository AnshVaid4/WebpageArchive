<?php include 'include/head.php'; ?>
<div class="cmid">
<div class="left">
	<?php include("include/contact.php");?>
</div>
<div class="right">
	<br><br><br>
	<h1><center>ADDRESS</center><br>
	<center>
		<h6><u>N2/H2-105 Deonar-105,Safdarjung,Delhi</u><br><u>Contact:</u> <u>9839784562</u></h6>
	</center>
</div>
</div>
<?php include("include/footer.php") ; ?>