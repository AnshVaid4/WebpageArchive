<?php include "include/head.php"; ?>

<div class="main">
<?php include("include/dashIncludeMenu.php");?>
<div class="right">
	<table style="margin-left: 170px;">
		<tr>
			<th style="font-size: 28px;width: 250px;">Employee Name</th>
			<th style="font-size: 28px;width: 350px;">Employee Designation</th>
			<th style="font-size: 28px;width: 200px;">Salary</th>
			<th style="font-size: 28px;width: 200px;">City</th>
			<th style="font-size: 28px;width: 200px;">State</th>
		</tr>
	</table>
</div>
</div>

<?php include "include/footer.php"; ?>