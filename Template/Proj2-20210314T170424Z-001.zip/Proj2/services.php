<?php include 'include/head.php'; ?>
<div class="mid">
	<br><br>
	<h1><u><center>Our Services</center></u></h1>
<div class="left">
	<img src="photos/download.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>

</div>
<div class="center">
	<img src="photos/download1.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	
</div>
<div class="right">
	<img src="photos/download2.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	  </p>

</div>
<div class="supright">
	<img src="photos/images1.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	
</div>
</div>
<div class="mid">
	<br><br>
<div class="left">
	<img src="photos/images2.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	
</div>
<div class="center">
	<img src="photos/images3.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	
</div>
<div class="right">
	<img src="photos/images4.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	  </p>
	  
</div>
<div class="supright">
	<img src="photos/images5.jpeg" height="280" width="100%">
	<p>Dummy text Dummy text Dummy text Dummy text
		Dummy text Dummy text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text
	   Dummy textDummy text
	   Dummy text
	   Dummy textvDummy textDummy textDummy textDummy text Dummy text
	    text Dummy text Dummy text
	   Dummy text Dummy text Dummy text Dummy text Dummy text</p>
	   
</div>
</div>


<?php include("include/footer.php") ; ?>