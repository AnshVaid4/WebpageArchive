<?php include "include/head.php"; ?>

<div class="main">
<?php include("include/dashIncludeMenu.php");?>
<div class="right">
	<table style="margin-left: 170px;">
		<tr>
			<th style="font-size: 28px;width: 250px;">Username</th>
			<th style="font-size: 28px;width: 250px;">Mobile</th>
			<th style="font-size: 28px;width: 250px;">Email</th>
			<th style="font-size: 28px;width: 280px;">Website URL</th>
			<th style="font-size: 28px;width: 280px;">Message</th>
		</tr>
	</table>
</div>
</div>

<?php include "include/footer.php"; ?>