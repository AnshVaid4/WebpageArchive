<?php include "include/head.php"; ?>

<div class="main">
<?php include("include/dashIncludeMenu.php");?>
<div class="right">

</div>
</div>

<?php include "include/footer.php"; ?>