<?php include "include/head.php"; ?>

<div class="main">
<?php include("include/dashIncludeMenu.php");?>
<div class="right">
	<table style="margin-left: 180px;">
		<tr>
			<th style="font-size: 28px;width: 250px;">Name</th>
			<th style="font-size: 28px;width: 250px;">Mobile</th>
			<th style="font-size: 28px;width: 250px;">Service</th>
			<th style="font-size: 28px;width: 250px;">Email</th>
			<th style="font-size: 28px;width: 250px;">Message</th>
		</tr>
	</table>
</div>
</div>

<?php include "include/footer.php"; ?>